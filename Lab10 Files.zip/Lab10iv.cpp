#include <fstream>
#include <iostream>
#include <string>
#include "stabbingLine.h"

using namespace std;

//x-coordinates
const int xcoord = 1;
const int xcoord1 = 3;
const int xcoord2 = 6;

void readPoints(int pointsArray[12]){

//Selects a text file
int cnt =0;
string filename("numbersi.txt");
ifstream inPutPointFile(filename);

//Reads the numbers from the text file and puts them in an array, pointArray
cout << "The integers from the text file, 'numbersi.txt', are: \n";

int x;
while(inPutPointFile >> x){
	pointsArray[cnt++] = x;
	cout << x << " ";
}


cout << endl;

//closes text file
inPutPointFile.close();

//Assigns Point Id to values and assigns x and y coordinates to indexes in the pointArray
p1.Pid = 0;
p1.x = pointsArray[0];
p1.y = pointsArray[1];

p2.Pid = 1;
p2.x = pointsArray[2];
p2.y = pointsArray[3];

p3.Pid = 2;
p3.x = pointsArray[4];
p3.y = pointsArray[5];

p4.Pid = 3;
p4.x = pointsArray[6];
p4.y = pointsArray[7];

p5.Pid = 4;
p5.x = pointsArray[8];
p5.y = pointsArray[9];

p6.Pid = 5;
p6.x = pointsArray[10];
p6.y = pointsArray[11];



}



void readLines(int lineArray[3]){

//Array for Line Id
for(int i=0; i<3; i++){
	lineArray[i]=i;
}

//Assigns Line Id to values and assigns line points to point id
l1.Lid = lineArray[0];
l1.point1 = p1.Pid;
l1.point2 = p2.Pid;

l2.Lid = lineArray[1];
l2.point1 = p3.Pid;
l2.point2 = p4.Pid;

l3.Lid = lineArray[2];
l3.point1 = p5.Pid;
l3.point2 = p6.Pid;

cout << "\nThese are the Line ids for the three lines\n";

for(int i=0; i<3; i++){
	cout << "Line:";
	cout << lineArray[i] << " " << endl;
}

}



void printLineByCoords(int lineArray[3], int pointsArray[12]){

//Prints out the lines and their coordinates
cout << "\nThese are the coordinates of the lines\n";

for(int i=0; i<3; i++){
	if(lineArray[i]==0){
		cout << "Line " << lineArray[i] << ": (" << p1.x << "," << p1.y << ")" << " (" << p2.x << "," << p2.y << ")"<< endl;
	}
	else if(lineArray[i]==1){
		cout << "Line " << lineArray[i] << ": (" << p3.x << "," << p3.y << ")" << " (" << p4.x << "," << p4.y << ")"<< endl;
	}
	else if(lineArray[i]==2){
		cout << "Line " << lineArray[i] << ": (" << p5.x << "," << p5.y << ")" << " (" << p6.x << "," << p6.y << ")"<< endl;
	}
	else{
	cout << "There is no such line" << endl;
	}
}


}

void getStabbedLines(int xcoord, int lineArray[3], int pointsArray[12]){

//Checks and prints out which lines were stabbed by the x-coordinate
cout << "\nAn x coordinate of " << xcoord << " goes through the graph\n" << endl;

for(int i=0; i<3; i++){
if(p2.x >= xcoord && p1.x <= xcoord){
	cout << "Line " << lineArray[i] << " was stabbed by the x-coordinate, " << "x = " << xcoord << endl; 
}

else if(p4.x >= xcoord && p3.x <= xcoord){
	cout << "Line " << lineArray[i] << " was stabbed by the x-coordinate, " << "x = " << xcoord << endl; 
}

else if(p6.x >= xcoord && p5.x <= xcoord){
	cout << "Line " << lineArray[i] << " was stabbed by the x-coordinate, " << "x = " << xcoord << endl; 
}

else{
	cout << "Line " << lineArray[i] << " was not stabbed by the x-coordinate" << endl;
}

}}

int main(){

int pointsArray[12];
int lineArray[3];
readPoints(pointsArray);
readLines(lineArray);
printLineByCoords(lineArray, pointsArray);
getStabbedLines(xcoord, lineArray, pointsArray);
getStabbedLines(xcoord1, lineArray, pointsArray);
getStabbedLines(xcoord2, lineArray, pointsArray);

return 0;
}
