#include <fstream>
#include <iostream>
#include <string>

typedef int PointId;
typedef int LineId;

//Structs
struct Point{
	PointId Pid;
	int x, y;
};

Point p1, p2, p3, p4, p5, p6;


struct Line{
	LineId Lid;
	PointId point1;
	PointId point2;
};

Line l1, l2, l3;
